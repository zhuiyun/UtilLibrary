package com.zhuiyun.library.utils




import androidx.appcompat.app.AppCompatActivity


/**

 * @author: yun

 * @date: 2022/6/21 0021 16

 */
object KeyboardUtils {
    /**
     * 隐藏软键盘(只适用于Activity，不适用于Fragment)
     */
    fun hideSoftKeyboard( activity: AppCompatActivity) {
        val view=activity.currentFocus;
        if (view != null) {
            val inputMethodManager = (InputMethodManager)activity.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }
}